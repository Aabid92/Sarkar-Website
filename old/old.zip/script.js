// ============================================================
//  RABBANI PEER – SUFI WEBSITE  |  script.js
// ============================================================

// ─── Page Navigation ────────────────────────────────────────
function showPage(pageId) {
  // Hide all pages
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));

  // Show target page
  const target = document.getElementById('page-' + pageId);
  if (target) {
    target.classList.add('active');
  } else {
    document.getElementById('page-home').classList.add('active');
  }

  // Scroll to top
  window.scrollTo({ top: 0, behavior: 'smooth' });

  // Close mobile nav
  document.getElementById('main-nav').classList.remove('open');
  document.querySelectorAll('.has-sub').forEach(el => el.classList.remove('open'));
}

// ─── Show Home on Load ───────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  showPage('home');
  initMobileNav();
  initStickyHeader();
});

// ─── Mobile Hamburger ────────────────────────────────────────
function initMobileNav() {
  const hamburger = document.getElementById('hamburger');
  const nav = document.getElementById('main-nav');

  hamburger.addEventListener('click', () => {
    nav.classList.toggle('open');
  });

  // Mobile sub-menu toggle (tap arrow/link to expand)
  document.querySelectorAll('.has-sub > .nav-link').forEach(link => {
    link.addEventListener('click', (e) => {
      if (window.innerWidth <= 900) {
        e.preventDefault();
        e.stopPropagation();
        const parent = link.closest('.has-sub');
        parent.classList.toggle('open');
      }
    });
  });

  // Close nav when clicking outside
  document.addEventListener('click', (e) => {
    if (!e.target.closest('#site-header')) {
      nav.classList.remove('open');
    }
  });
}

// ─── Sticky Header Shadow ────────────────────────────────────
function initStickyHeader() {
  const header = document.getElementById('site-header');
  window.addEventListener('scroll', () => {
    if (window.scrollY > 10) {
      header.style.boxShadow = '0 4px 30px rgba(0,0,0,0.6)';
    } else {
      header.style.boxShadow = '0 2px 20px rgba(0,0,0,0.5)';
    }
  });
}

// ─── FAQ Accordion ───────────────────────────────────────────
function toggleFaq(btn) {
  const answer = btn.nextElementSibling;
  const isOpen = btn.classList.contains('open');

  // Close all
  document.querySelectorAll('.faq-q').forEach(b => {
    b.classList.remove('open');
    b.nextElementSibling.classList.remove('open');
  });

  // Open clicked one if it was closed
  if (!isOpen) {
    btn.classList.add('open');
    answer.classList.add('open');
  }
}

// ─── Contact Form ────────────────────────────────────────────
function handleContact(e) {
  e.preventDefault();
  const btn = e.target.querySelector('button[type="submit"]');
  const original = btn.textContent;
  btn.textContent = '✓ Message Sent!';
  btn.style.background = 'linear-gradient(135deg, #2a6640, #1a4a28)';
  btn.style.color = '#f5f0e8';
  setTimeout(() => {
    btn.textContent = original;
    btn.style.background = '';
    btn.style.color = '';
    e.target.reset();
  }, 3000);
}
